﻿namespace EmployeeWebAPI.Models
{
    public class CustomerDestination
    {
        //public int CustId { get; set; }
        public int Id { get; set; }

       // public string CustName { get; set; }
        public string Name { get; set; }


    }
}
