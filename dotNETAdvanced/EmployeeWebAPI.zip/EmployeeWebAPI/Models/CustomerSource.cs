﻿namespace EmployeeWebAPI.Models
{
    public class CustomerSource
    {
        public int CustId { get; set; }
        public string CustName { get; set; }
        public string City { get; set; }
        public string Region { get; set; }
    }
}
