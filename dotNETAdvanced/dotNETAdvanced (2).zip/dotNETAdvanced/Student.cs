﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace dotNETAdvanced
{
    internal class Student
    {
        public int sid { get; set; }
        public string sname{ get; set; }
        public int age { get; set; }    
        public int tid { get; set; }
    }
}
