﻿namespace ShelfProducts.Models
{
    public class Product
    {
        public string Pname { get; set; }
        public int Pcode { get; set; }

        public string Bname { get; set; }
        public int Sleft { get; set; }
        public decimal price { get; set; }
        public DateTime dt { get; set; }

    }
}
